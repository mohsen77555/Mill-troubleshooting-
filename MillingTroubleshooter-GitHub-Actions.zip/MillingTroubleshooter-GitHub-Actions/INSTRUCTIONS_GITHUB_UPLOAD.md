# How to upload this project to GitHub and build the APK automatically

## Method 1: GitHub website

1. Download and extract the ZIP.
2. Go to GitHub and create a new repository, for example `milling-troubleshooter-android`.
3. Open the extracted folder.
4. Select and upload all files and folders inside it:
   - `.github`
   - `app`
   - `build.gradle`
   - `settings.gradle`
   - `gradle.properties`
   - `.gitignore`
   - `README.md`
5. Commit the upload.
6. Open the **Actions** tab.
7. Click **Build Android APK**.
8. After it finishes, download the APK from **Artifacts**.

## Method 2: Git commands

```bash
git init
git branch -M main
git add .
git commit -m "Initial Android APK builder"
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Then open GitHub → **Actions** → **Build Android APK** → download the artifact.

## Manual run

The workflow can also be started manually from GitHub:

Actions → Build Android APK → Run workflow
